package com.example.barcode;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;

import android.Manifest;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.Point;
import android.graphics.drawable.BitmapDrawable;
import android.net.Uri;
import android.os.Bundle;
import android.os.Environment;
import android.util.Log;
import android.view.Display;
import android.view.View;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.Toast;

import com.google.zxing.WriterException;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.OutputStream;

import androidmads.library.qrgenearator.QRGContents;
import androidmads.library.qrgenearator.QRGEncoder;

public class MainActivity extends AppCompatActivity {
    String TAG = "Generate Bar Code";
    EditText editTxt ;
    ImageView barimage;
    String inputValue;
    Button start,send,save;
    Bitmap bitmap;
    OutputStream outputStream;
    QRGEncoder qrgEncoder;
    private static final String TAGS = "MainActivity";
    Intent intent = null,chooser=null;

    @Override
    protected void onCreate(Bundle savedInstanceState) {

        ActivityCompat.requestPermissions(MainActivity.this,new String[]{Manifest.permission.WRITE_EXTERNAL_STORAGE},1);
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        barimage = (ImageView)findViewById(R.id.barcode);
        editTxt = (EditText)findViewById(R.id.editText);
        start = (Button)findViewById(R.id.createbtn);
        send = (Button)findViewById(R.id.sendbtn);
        save = (Button)findViewById(R.id.savebtn);

        start.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                inputValue = editTxt.getText().toString().trim();
                if(inputValue.length()>0){
                    WindowManager manager = (WindowManager)getSystemService(WINDOW_SERVICE);
                    Display display = manager.getDefaultDisplay();
                    Point point = new Point();
                    display.getSize(point);
                    int width = point.x;
                    int height = point.y;
                    int smallerdimension = width<height?width:height;
                    smallerdimension=smallerdimension*3/4;
                    qrgEncoder = new QRGEncoder(inputValue,null, QRGContents.Type.TEXT,smallerdimension);
                    try{
                        bitmap=qrgEncoder.encodeAsBitmap();
                        barimage.setImageBitmap(bitmap);

                    } catch (WriterException e) {
                        Log.v(TAG,e.toString());
                    }

                }else{
                    editTxt.setError("Required");
                }
            }
        });
//        send.setOnClickListener(new View.OnClickListener() {
//            @Override
//            public void onClick(View v) {
//                Log.d(TAGS,"send email:");
//
//                String[] TO_EMAILS = {};
//                String[] CC = {};
//                String[] BCC = {};
//                System.out.println(barimage.getClass().getName());
//
//                Intent intent = new Intent(Intent.ACTION_SENDTO);
//                intent.setData(Uri.parse("mailto:"));
//                intent.putExtra(Intent.EXTRA_SUBJECT, "poulta form insertion");
//                intent.putExtra(Intent.EXTRA_TEXT, inputValue);
//
//                startActivity(Intent.createChooser(intent,"choose one application"));
//
////                System.out.println(barimage.getClass().getName());
//
//
//            }
//        });


        save.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                BitmapDrawable drawable = (BitmapDrawable)barimage.getDrawable();
                Bitmap bitmaps = drawable.getBitmap();
                FileOutputStream outStream = null;
                File filepath = Environment.getExternalStorageDirectory();
                File dir = new File(filepath.getAbsolutePath()+"/Demo");
                dir.mkdir();
                String filename = String.format("%d.jpg",System.currentTimeMillis());
                File outfile = new File(dir,filename);
                Toast.makeText(MainActivity.this,"Image saved",Toast.LENGTH_SHORT).show();

                try {
                    outStream = new FileOutputStream(outfile);
                    bitmaps.compress(Bitmap.CompressFormat.JPEG,100,outStream);
                    outStream.flush();
                    outStream.close();

                    Intent intent = new Intent(Intent.ACTION_MEDIA_SCANNER_SCAN_FILE);
                    intent.setData(Uri.fromFile(outfile));
                    sendBroadcast(intent);
//                    System.out.println(filepath);
//                    System.out.println(file);
//                    System.out.println(outStream);

                } catch (FileNotFoundException e) {
                    e.printStackTrace();
                } catch (IOException e) {
                    e.printStackTrace();
                }
//                Toast.makeText(MainActivity.this,"Folder created",Toast.LENGTH_SHORT).show();

            }
        });

    }
//
//
//    public void sendemail(View view){
//        Log.d(TAGS,"send email:");
//
//        String[] TO_EMAILS = {};
//        String[] CC = {};
//        String[] BCC = {};
//
//        Intent intent = new Intent(Intent.ACTION_SENDTO);
//        intent.setData(Uri.parse("mailto:"));
//        intent.putExtra(Intent.EXTRA_TEXT, String.valueOf(barimage));
//        startActivity(Intent.createChooser(intent,"choose one application"));
//
//    }
    public void process(View view){
        if (view.getId() == R.id.sendbtn){
            Uri imageUri = Uri.parse(String.valueOf(bitmap));
            intent = new Intent(Intent.ACTION_SEND);
            intent.setType("image/*");
            intent.putExtra(Intent.EXTRA_STREAM,imageUri);
            intent.putExtra(Intent.EXTRA_TEXT,"Kindly find attached file");
            chooser=intent.createChooser(intent,"Send Image");
            startActivity(chooser);
        }
    }
}
